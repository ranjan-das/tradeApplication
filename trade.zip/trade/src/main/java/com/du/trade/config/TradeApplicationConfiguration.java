package com.du.trade.config;

import com.du.trade.repository.TradeRepository;
import com.du.trade.service.TradeUploadService;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TradeApplicationConfiguration {

    @Bean
    @Qualifier("tradeUploadService")
    TradeUploadService tradeUploadService(TradeRepository tradeRepository) {
        return new TradeUploadService(tradeRepository);
    }
}
