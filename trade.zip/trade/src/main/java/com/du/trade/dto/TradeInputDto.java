package com.du.trade.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TradeInputDto {
    private String tradeId;
    private String counterPartyId;
    private long version;
    private String bookId;
}
