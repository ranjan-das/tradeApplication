package com.du.trade.resource;

import com.du.trade.dto.TradeInputDto;
import com.du.trade.service.TradeUploadService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class TradeResource {
    private final TradeUploadService tradeUploadService;

    @PostMapping("/trade/upload")
    public void uploadTradeRecord(final TradeInputDto tradeInputDto) {
        tradeUploadService.uploadTrade(tradeInputDto);
    }

}
