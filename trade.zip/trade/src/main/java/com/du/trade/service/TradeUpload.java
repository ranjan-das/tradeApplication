package com.du.trade.service;

import com.du.trade.dto.TradeInputDto;
import com.du.trade.repository.TradeRepository;

public interface TradeUpload {
    public void uploadTrade(TradeInputDto tradeInputDto);
}
