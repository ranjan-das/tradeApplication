package com.du.trade.service;


import com.du.trade.dto.Trade;
import com.du.trade.dto.TradeInputDto;
import com.du.trade.repository.TradeRepository;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class TradeUploadService implements TradeUpload {

    private final TradeRepository tradeRepository;

    @Override
    public void uploadTrade(TradeInputDto tradeInputDto) {
        //validation

        //map tradeInputDto -> trade and add createdDate and expired flag
        Trade trade = new Trade();

          tradeRepository.save(trade);
    }
}
